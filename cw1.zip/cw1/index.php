<?php

 // kilka części mojego kodu zabrałem ze strony Pana Profesora, jednakże przestudiowałem go i dopiero po nim zacząłem rozumieć jak działa cały system sesji i logowań
   // potem dodaj tutaj jeszcze jakiś css
   // komentarze są moje i pokazują jak ja to widzę
   // od ostatniej lekcji nabrałem nawyk sprawdzania credits na począku większości plików, ułatwia to poruszanie się, wyjątkiem jest forwarding bo wtedy sprawdzone to zostało wcześniej
   

//ustalam tutaj miejsca gdzie i jak sie konkretnie lokalizują
require_once 'config_credit.php';


//podstawowa sciezka dla programu
include _ROOT_PATH.'/app/credit_view.php';